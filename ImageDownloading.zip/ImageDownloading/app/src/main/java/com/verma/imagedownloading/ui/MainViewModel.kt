package com.verma.imagedownloading.ui

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel
import com.verma.imagedownloading.data.repository.DownloaderRepository

class MainViewModel @ViewModelInject constructor(
    private val repository: DownloaderRepository
) : ViewModel() {

}